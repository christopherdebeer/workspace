# What the gesture was drawn for

This intent was written down before the gesture was drawn. Your expectation and critique are locked; do not revise them. Two separate questions:

- recovered (yes, partly, no) and recoveredBy: did your PREFERRED reading express this intent? Which of your hypotheses (if any) matches it?
- toyVerdict: judged against THIS intent, not yours, what did the toy make of it (fulfilled, acceptable-alternative, partial, misread, no-effect, unjudgeable)?

evidence: from the before/after images and the visible text. gap: the difference in a phrase, empty if none. Fill judgment.json and run judge.
