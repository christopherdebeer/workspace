# land12-1: BEFORE ONLY

Inspect the before image and before.json. Do not open sealed/ or any after files.
Record what the hand could reasonably mean, independently of implementation rules.
Allow multiple hypotheses and ambiguous or unjudgeable cases. Cite visible evidence.
State observable criteria, what should remain unchanged, unacceptable surprises, and expected live feedback.
Do not infer intent from a future result. Fill expectation.json, set blind=true only if accurate, then commit with expect.
