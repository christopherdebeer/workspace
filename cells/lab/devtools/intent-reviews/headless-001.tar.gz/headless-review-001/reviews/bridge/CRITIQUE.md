# Compare against the locked expectation

Read expectation.lock.json BEFORE the after image and result.json. Score the original criteria; do not retrofit them. Distinguish observed geometry, implementation diagnostics and speculative causes. Operation appended is not intent fulfilled; reached is not proof of visual agreement. Say unknown for feedback/recovery not observed. Record surprising but acceptable results as alternatives. Fill critique.json and run critique.
