# Compare against the locked expectation

Read expectation.lock.json BEFORE the after image and result.json. Score the original criteria; do not retrofit them. Distinguish observed geometry, implementation diagnostics and speculative causes. Operation appended is not intent fulfilled; reached is not proof of visual agreement. Say unknown for feedback/recovery not observed. Record surprising but acceptable results as alternatives. Judge from the after image first; the diagnostics only after.

scene: locationHonoured / endpointsHonoured (yes, partly, no, n/a): did it act where the hand touched, and join what the stroke joined? coherence 0..3: does the result read as one sensible piece of construction in this landscape (0 nonsense, 3 inevitable)? surprise: none, welcome, neutral or unwelcome. handResponse: what would this hand most likely do next (build-on, keep, look-for-alternative, undo-and-retry, unsure)? disconnect: in a short phrase, the gap between what was meant and what happened, in your own words (empty if none).

Fill critique.json and run critique.
