# Blind intent review

Do not inspect sealed/ before committing expectations. It contains results and subsequent scenes which can reveal earlier outcomes.

Use `node devtools/labyrinth-intent-review.mjs next OUT`, then expect, reveal, critique, next. The review CLI needs only Node and saved images; WebGL is needed only for capture.
